function initialize(owner)
	placement = tolua.cast(ObjectManager:getInstance():getComponent(owner, CT_PLACEMENT), "Placement")
end

function finalize()

end

function handleMessage(message)
end

function update()
	position = placement:getPosition()
	position.z = 0
	placement:setPosition( position, true )
end