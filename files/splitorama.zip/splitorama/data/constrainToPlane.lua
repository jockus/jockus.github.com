function initialize(owner)
	body = tolua.cast(ObjectManager:getInstance():getComponent(owner, Body:getTypeStatic()), "Body")
	placement = tolua.cast(ObjectManager:getInstance():getComponent(owner, Placement:getTypeStatic()), "Placement")
end

function finalize()

end

function handleMessage(message)
end

function update(timeSteip)
	--Script is not the way to do sthis, use physics constraints instead
	placement:setPosition( Vector( placement:getPosition().x, placement:getPosition().y , 0 ), true )
	orientation = Quaternion( placement:getOrientation()[0], 0, 0, placement:getOrientation()[3] )
	orientation:normalise()
	placement:setOrientation( orientation )
end