function initialize(owner)
	body  = tolua.cast(ObjectManager:getInstance():getComponent(owner, Body:getTypeStatic()), "Body")
end

function finalize()

end

function handleMessage(message)
end

function update(timeStep)
end


function onCollision(collidee)
	if(collidee=="Goal") then
		Engine:loadLevel("board.scene")
	end
	if(collidee=="Goal") then
		Engine:loadLevel("board.scene")
	end
end