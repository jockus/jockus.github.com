local alphabegin = 1
local alphafinish = 0
local alpha = alphabegin
local timeToFinish = 2
function initialize(owner)
	overlay  = tolua.cast(ObjectManager:getInstance():getComponent(owner, Overlay:getTypeStatic()), "Overlay")
end

function finalize()

end

function handleMessage(message)
end

function update(timeStep)
    if( alpha > alphafinish) then
        overlay:setAlpha( alpha )
        alpha = alpha + ( (  alphafinish - alphabegin ) / timeToFinish ) * timeStep
    end
end
