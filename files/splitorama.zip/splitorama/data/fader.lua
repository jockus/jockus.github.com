local alphabegin = 1
local alphafinish = 0
local alpha = alphabegin
local timeToFadeUp = 2.5
local timeToFadeDown = 1
local waitTime=1
local state="fadeup"
function initialize(owner)
	overlay  = tolua.cast(ObjectManager:getInstance():getComponent(owner, Overlay:getTypeStatic()), "Overlay")
end

function finalize()

end

function handleMessage(message)
end

function update(timeStep)
	if ( state == "fadeup" ) then
		if( alpha > alphafinish) then
			overlay:setAlpha( alpha )
			alpha = alpha + ( (  alphafinish - alphabegin ) / timeToFadeUp ) * timeStep
		else
			state = "wait"
		end
	end
	if ( state == "wait" ) then
		if( waitTime > 0 ) then
			waitTime = waitTime - timeStep
		else
			state = "fadedown"
		end
	end
	
	if ( state == "fadedown" ) then
		if( alpha < alphabegin) then
			overlay:setAlpha( alpha )
			alpha = alpha + ( ( alphabegin -  alphafinish ) / timeToFadeDown ) * timeStep
		else
			state = "finished"
		end
	end
	
	if ( state == "finished" ) then
		Engine:loadLevel("board.scene")
	end
end
