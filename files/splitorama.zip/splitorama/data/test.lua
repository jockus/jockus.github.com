function test1()
	 local number = 0;
	 while(1) do
		print("Testing again!" .. number);
		Thread.WaitFrame();
		number = number + 1;
		if number == 20 then
			break;
		end
	end
end

function same()
	print("same test.lua");
	print("creating a splitorama");
	print("foo equals " .. foo .. " in function same.")
	v = Vector:new(3, 2, 1)
	printVector(v)
	v2 = v + Vector.UNIT_X
	printVector(v2)
	q = Quaternion.IDENTITY
	printQuaternion(q)
end

function doStuff(v, n)
	print("got two values: ")
	printVector(v)
	print(n)
	return 3.14
end

function testend()
	if(string) then
		print(string)
	end
end

function printVector(v)
	print("X: " .. v[0] .. " Y: " .. v[1] .. " Z: " .. v[2])
end

function printQuaternion(q)
	print("W: " .. q[0] .. " X: " .. q[1] .. " Y: " .. q[2] .. " Z: " .. q[3])
end


foo = 4

print("foo equals " .. foo .. " at startup");