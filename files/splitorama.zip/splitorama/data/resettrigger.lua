function initialize(owner)
end

function finalize()
end

function handleMessage(message)
	if(message:getMessage() == "collision") then
		--collidee = tolua.cast( message:getData(), "std::string*" )
		--placement = tolua.cast(ObjectManager:getInstance():getComponent( collidee, Placement:getTypeStatic() ), "Placement" )
		--placement:setPosition( Vector( 0, 20, 0 ) )
		print("Triggered")
	end
end

function update(timeStep)
end