--
-- Testcomponent
--
--
--
local owner
local body
local mgr = ObjectManager:getInstance()

function finalize()
	print("destroyng scriptcomponent")
end

function initialize(object)
	if(object == nil) then
		print("invalid object")
	else
		print("intializing object: " .. object)
		body = mgr:getComponent(owner, Body:getTypeStatic())
		if(body == nil) then
			print("no body in owner")
		end	
	end
end

function handleMessage(message)
	print("handling message")
	d = message:getData()
	if(message:getMessage() == MT_UPDATE) then
		v = tolua.cast(message:getData(), "Vector")
		printVector(v)
	else
		print("Unknown message.")

		--print("recieved message: " .. d)
	end
	--printVector(message:getData())	
end

function update(timeStep)
	print("Timestep: " .. timeStep)
end


function printVector(v)
	print("X: " .. v[0] .. " Y: " .. v[1] .. " Z: " .. v[2])
end