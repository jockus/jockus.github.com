testContext = ContextManager:getInstance():getContext("Development")
walkAction = testContext:getAction("Keyboard17")
walkBackAction = testContext:getAction("Keyboard31")
rotateLeftAction = testContext:getAction("Keyboard30")
rotateRightAction = testContext:getAction("Keyboard32")
resetAction = testContext:getAction("Keyboard19")

function initialize(owner)
	skeleton = tolua.cast(ObjectManager:getInstance():getComponent(owner, Skeleton:getTypeStatic()), "Skeleton")
	body = tolua.cast(ObjectManager:getInstance():getComponent(owner, Body:getTypeStatic()), "Body")
	placement = tolua.cast(ObjectManager:getInstance():getComponent(owner, Placement:getTypeStatic()), "Placement")
end

function finalize()

end

function handleMessage(message)
end

function update(timeStep)
	updateWalk(timeStep)
end

isWalking = false
isWalkingBack = false
function updateWalk(timeStep)

	if walkAction:getHeld() and not isWalking  then
		isWalking = true
		skeleton:play( "Walk" )
	end
	
	if not walkAction:getHeld() and isWalking  then
		isWalking = false
		skeleton:stop( "Walk" )
	end
	
	if isWalking then
		body:setRelativeLinearVelocity( Vector( 3, 0, 0 ) )
	end
	
	if walkBackAction:getHeld() and not isWalkingBack  then
		isWalkingBack = true
		skeleton:play( "Walk" )
	end
	
	if not walkBackAction:getHeld() and isWalkingBack  then
		isWalkingBack = false
		skeleton:stop( "Walk" )
	end
	
	if isWalkingBack then
		body:setRelativeLinearVelocity( Vector( -3, 0, 0 ) )
	end
	
	if rotateLeftAction:getHeld() then
		body:addRelativeTorque( Vector( 0, 100, 0 ) )
	end
	
	if rotateRightAction:getHeld() then
		body:addRelativeTorque( Vector( 0, -100, 0 ) )
	end
	
	if resetAction:getClicked() then
		placement:setOrientation( Quaternion.IDENTITY )
	end

end
