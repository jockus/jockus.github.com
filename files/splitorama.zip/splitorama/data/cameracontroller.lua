--throttle = false

testContext = ContextManager:getInstance():getContext("Development")
--forwardAction = testContext:getAction("JoystickAxis0")
--horizontalAction = testContext:getAction("JoystickAxis1")
--verticalAction = testContext:getAction("JoystickAxis2")

strafeRight = testContext:getAction("D")
strafeLeft = testContext:getAction("A")
forward = testContext:getAction("W")
backward = testContext:getAction("S")
speedUp = testContext:getAction("SHIFT")

lookHorizontal = testContext:getAction("MouseX")
lookVertical = testContext:getAction("MouseY")

lookAction = testContext:getAction("MouseRight")

keyboardUp = testContext:getAction("Keyboard200")
keyboardDown = testContext:getAction("Keyboard208")
keyboardLeft = testContext:getAction("Keyboard203")
keyboardRight = testContext:getAction("Keyboard205")
keyboardPageUp = testContext:getAction("Keyboard201")
keyboardPageDown = testContext:getAction("Keyboard209")

function initialize(owner)
	--body = tolua.cast(ObjectManager:getInstance():getComponent(owner, Body:getTypeStatic()), "Body")
	placement = tolua.cast(ObjectManager:getInstance():getComponent(owner, Placement:getTypeStatic()), "Placement")
end

function finalize()

end

function handleMessage(message)
end

function update(timeStep)
	if( Engine:isInEditor() ) then
		if( lookAction:getHeld() ) then
			orientationSpeed = 10280
			orientationChange = Quaternion( Ogre.Radian( Ogre.Degree( prevY - lookHorizontal:getValue() ) * orientationSpeed * timeStep ), Vector.UNIT_Y )
			orientationChange = orientationChange * Quaternion( Ogre.Radian( Ogre.Degree( prevX - lookVertical:getValue() ) * orientationSpeed * timeStep ), Vector.UNIT_X )
			--orientationChange = orientationChange * 
			orientationChange:normalise()
			x = orientationChange:xAxis()
			y = orientationChange:yAxis()
			z = orientationChange:zAxis()
			orientationChange = Quaternion(x, y, Vector.UNIT_Z)
			newOrientation = placement:getOrientation() * orientationChange
			placement:setOrientation( newOrientation, true )
		end
		
		positionChange = placement:getOrientation() * Vector( strafeRight:getValue() - strafeLeft:getValue(), 0, backward:getValue() - forward:getValue() )
		positionSpeed = 20 + 20 * ( 4 * speedUp:getValue() )
		placement:setPosition( placement:getPosition() + positionChange * positionSpeed * timeStep, true )
	end
	prevX = lookVertical:getValue()
	prevY = lookHorizontal:getValue()
end