
--store our object nae
function initialize(playerobjectname)
	object = playerobjectname
end

function ThrottleOn()
	print("Throttle On!")
	ObjectManager:getInstance():sendMessage(object, Message("throttle_on"))
end

function ThrottleOff()
	print("Throttle Off!")
	ObjectManager:getInstance():sendMessage(object, Message("throttle_off"))
end

function TurnLeftOn()
	ObjectManager:getInstance():sendMessage(object, Message("turn_left_on"))
end

function TurnLeftOff()
	ObjectManager:getInstance():sendMessage(object, Message("turn_left_off"))
end

function fun()
	print("Fun!")
end

function mouseX(position)
	mx = position
end

function mouseY(position)
	my = position
end

function mouseB()
	print("Press at " .. mx .. ", " .. my)
end

console = {}
function console.Say(player, message)
	ObjectManager:getInstance():sendMessage("Chat", player .. ": " .. message)
end
