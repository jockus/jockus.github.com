  function trace (event, line)
      local s = debug.getinfo(2)
    print(s.short_src .. ":" .. line)
    end
    
    debug.sethook(trace, "l")

print("test.lua loaded");