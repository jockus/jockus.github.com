function initialize(owner)
end

function finalize()

end

function handleMessage(message)
end

name = "SpawnedBall"
instance = 0
function update(timeStep)
	if( math.random() > 0.99 ) then
		Engine:spawn( name .. instance, "Ball" )
		instance = instance + 1
	end
end
