-- get CEGUI singletons
local logger = CEGUI.Logger:getSingleton()
--logger:setLoggingLevel( CEGUI.Informative )

-- get a local reference to the singletons we use (not required)
local system    = CEGUI.System:getSingleton()
local fontman   = CEGUI.FontManager:getSingleton()
local schememan = CEGUI.SchemeManager:getSingleton()
local winman	= CEGUI.WindowManager:getSingleton()

-- load schemes
schememan:loadScheme( "WindowsLook.scheme" )

-- load a default font
-- local font = fontman:createFont( "bluehighway-10.font" )

-- set default mouse cursor
-- Would rather use hardware mouse
-- system:setDefaultMouseCursor( "TaharezLook","MouseArrow" )

-- set up some temporary gui
system:setGUISheet( winman:createWindow( "DefaultWindow", "root" ) )

osd = winman:loadWindowLayout("osd.layout")
system:getGUISheet():addChildWindow(osd)

window = winman:loadWindowLayout("ogregui.layout")
system:getGUISheet():addChildWindow(window)
winman:getWindow("Demo8/Window1/Controls/Editbox"):setText( Engine:getCurrentScene() )
window:hide()

function handleNew()
	--Engine:loadLevel()
	winman:destroyAllWindows()
	window = winman:loadWindowLayout("ogregui.layout")
	system:setGUISheet(window)
end

function update(time)
	winman:getWindow("FPS"):setText( Engine:getFPS() )
end

function handleLoad()
	Engine:loadLevel( winman:getWindow("Demo8/Window1/Controls/Editbox"):getText() )
end

function hideGUI()
	system:getGUISheet():hide()
end

function toggleDebugGeometries()
	Engine:toggleDebugGeometries()
end

function reloadGUI()
	winman:destroyAllWindows()
	window = winman:loadWindowLayout("ogregui.layout")
	system:setGUISheet(window)
end

function handleQuit()
	Engine:close()
end

-- Executes a given string
function handleExecute()
	loadstring( winman:getWindow("Command"):getText() )()
end

function handleReloadScripts()
	Engine:reloadScripts()
end

function handleReloadGUI()
	winman:destroyAllWindows()
	window = winman:loadWindowLayout("ogregui.layout")
	system:setGUISheet(window)
end

function hideGUI()
	window:hide()
end