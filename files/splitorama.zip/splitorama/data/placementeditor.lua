testContext = ContextManager:getInstance():getContext("Development")
mouseX = testContext:getAction("MouseX")
mouseY = testContext:getAction("MouseY")
grab = testContext:getAction("G")
picked=false
startX=0
startY=0
startPosition=Vector.ZERO

function initialize(owner)
	placement = tolua.cast(ObjectManager:getInstance():getComponent(owner, Placement:getTypeStatic()), "Placement")
end

function finalize()

end

function handleMessage(message)
	if(message:getMessage() == "EditorPicked" and not picked) then
		picked=true
		startX=mouseX:getValue()
		startY=mouseY:getValue()
		startPosition=placement:getPosition()
		print("picked")
	end
	if(message:getMessage() == "EditorReleased" and picked) then
		picked=false
		print("released")
	end
end

function update(timeStep)
	if picked and grab:getHeld() and Engine:isInEditor() then
		distanceFromCamera=20
		placement:setPosition( startPosition + Vector( mouseX:getValue() - startX, -(mouseY:getValue() - startY), 0) * distanceFromCamera, true )
		--print(placement:getPosition().x .. placement:getPosition().y )
		--print(mouseX:getValue())
	end
end
