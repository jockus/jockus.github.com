number = 2;

function test2()
	while(1) do
		print("second test loop");
		Thread.WaitFrame();
	end
end

function same()
	print("same test2.lua");
end