--throttle = false

testContext = ContextManager:getInstance():getContext("Development")
forwardAction = testContext:getAction("I")
backAction = testContext:getAction("K")
leftAction = testContext:getAction("J")
rightAction = testContext:getAction("L")

function initialize(owner)
	body = tolua.cast(ObjectManager:getInstance():getComponent(owner, Body:getTypeStatic()), "Body")
	placement = tolua.cast(ObjectManager:getInstance():getComponent(owner, Placement:getTypeStatic()), "Placement")
end

function finalize()

end

function handleMessage(message)
end

function update(timeStep)
	applyforces()
end

--hovermodel constants
throttleforce = 40000 
brakeforce = 50000 
turnforce = 8000 

function applyforces()
	--stop us from falling to quickly. We'll shoot rays to the ground
	--to determine the hoverforce later on.
	if(placement:getPosition().y < 5) then
	--	body:addForce(Vector(0, 8000, 0))
	end
	
	--if throttle button is set, give us force forwards
	if(throttle) then
		body:addRelativeForce(Vector(0, 0, throttleforce))
	end
	
	if(brake) then
		body:addRelativeForce(Vector(0, 0, -brakeforce))
	end
	
	if(left) then
		--body:addRelativeTorque(Vector(0, turnforce, 0))
		body:addRelativeForceAt(Vector(turnforce, 0, 0), Vector(0, 0, 7))
	end
	
	
	body:addRelativeForce(Vector(0, 0, throttleforce * forwardAction:getValue()))
	body:addRelativeForceAt(Vector(turnforce * leftAction:getValue(), 0, 0), Vector(0, 0, 7))
	body:addRelativeForceAt(Vector(-turnforce * rightAction:getValue(), 0, 0), Vector(0, 0, 7))
	body:addRelativeForce(Vector(0, 0, -throttleforce * backAction:getValue()))
	
	if(right) then
		--body:addRelativeTorque(Vector(0, -turnforce, 0))
		body:addRelativeForceAt(Vector(-turnforce, 0, 0), Vector(0, 0, 7))
	end
end