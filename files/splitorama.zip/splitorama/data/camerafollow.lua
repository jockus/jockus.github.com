function initialize(owner)
	placement = tolua.cast(ObjectManager:getInstance():getComponent(owner, Placement:getTypeStatic()), "Placement")
	targetPlacement = tolua.cast(ObjectManager:getInstance():getComponent("Board", Placement:getTypeStatic()), "Placement")
	targetBody = tolua.cast(ObjectManager:getInstance():getComponent("Board", Body:getTypeStatic()), "Body")
	length = 40
end

function finalize()

end

function handleMessage(message)
end

function update(timeStep)
	z = ( length + 0.5 * targetBody:getLinearVelocity():length() ) - placement:getPosition().z 
	cameraToTarget = Vector( targetPlacement:getPosition().x - placement:getPosition().x, targetPlacement:getPosition().y - placement:getPosition().y, z );
	followSpeed = 0.5 + targetBody:getLinearVelocity():length() * 0.05
	placement:setPosition( placement:getPosition() + cameraToTarget * followSpeed * timeStep, true )
end