#ifndef INCLUDED_EXAMPLEUTIL
#define INCLUDED_EXAMPLEUTIL

#include <string>

namespace ExampleUtil {
	void draw3DBackground();	//Draw fancy spheres
	void drawCenteredText(float x, float y, const std::string& text);
	void drawExampleRectangle(float x, float y, float width, float height, float alpha);
	void initialize(int x, int y);
	void resize(int x, int y);
	int screenWidth();
	int screenHeight();
	void setupFor3D();	//Prepare for 3D
	void setupFor2D();	//Prepare for 2D
	float textWidth(const std::string& text);
	float textHeight(const std::string& text);
}

#endif