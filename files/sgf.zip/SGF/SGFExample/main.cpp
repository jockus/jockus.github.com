#include "GL/freeglut.h"
#include "SGF.h"
#include "exampleutil.h"

class GLButton : public SGFComponent {
	float mAlpha;
public:
	GLButton(const SGFRectangle& bounds) :
		SGFComponent(bounds),
		mAlpha(0.3f) {
	  }
	  virtual void onButtonDown(int button, const SGFPosition& position) {
		  glutLeaveMainLoop();
	  }
	  virtual void onFocus() {
		  mAlpha = 0.6f;
	  }
	  virtual void onUnFocus() {
		  mAlpha = 0.3f;
	  }
	virtual void onDraw(const SGFPosition& position) {
		const SGFPosition p = position + getBounds().getPosition();
		const float width = getBounds().getWidth();
		const float height = getBounds().getHeight();

		ExampleUtil::drawExampleRectangle(p.getX(), p.getY(), width, height, mAlpha);
	}
};

class GLLabel : public SGFComponent {
	std::string mCaption;
public:
	GLLabel(const SGFPosition& position, const std::string& caption) :
	  SGFComponent(SGFRectangle(position, SGFAlignment::CENTER, ExampleUtil::textWidth(caption), ExampleUtil::textHeight(caption))),
	  mCaption(caption) {
	}
	virtual void onDraw(const SGFPosition& position) {
		const SGFPosition p = position + getBounds().getPosition();
		const float width = getBounds().getWidth();
		const float height = getBounds().getHeight();
		ExampleUtil::drawCenteredText(p.getX() + width * 0.5f, p.getY() + height * 0.5f, mCaption);
	}
};

/* FILE-SCOPE INSTANCES */
static SGFWindow* rootWindow;
static SGFSystem* gui;
static SGFWindow* quitDialog;
static GLButton* quitButton;
static GLLabel* quitLabel;

/* FILE-SCOPE FUNCTIONS */
static void initialize() {
	//create our gui and its root
	rootWindow = new SGFWindow(SGFRectangle(SGFPosition(0.0f, 0.0f), 1.0f, 1.0f));
	gui = new SGFSystem(rootWindow);
	
	//create our quit dialog
	quitDialog = new SGFWindow(SGFRectangle(SGFPosition(0.5f, 0.7f), SGFAlignment(0.5f, 0.5f), 0.4f, 0.2f));
	
	//create the button and add it to the dialog
	quitButton= new GLButton(SGFRectangle(SGFPosition(0.0f, 0.0f), 0.4f, 0.2f));
	quitDialog->addComponent(quitButton);
	
	//create the informative label and add it to the dialog
	quitLabel = new GLLabel(SGFPosition(0.2f, 0.1f), "Press here to quit!");
	quitDialog->addComponent(quitLabel);
	
	//finally add our dialog to the gui root
	rootWindow->addComponent(quitDialog);
}

static void finalize() {
	delete quitDialog;
	delete quitButton;
	delete quitLabel;
	delete rootWindow;
	delete gui;
}

static void render() {
	ExampleUtil::setupFor3D();
	ExampleUtil::draw3DBackground();
	ExampleUtil::setupFor2D();
	gui->postDraw();
	glutSwapBuffers();
}

static void motion(int x, int y) {
	SGFPosition p(x / (float) ExampleUtil::screenWidth(), y / (float) ExampleUtil::screenHeight());
	gui->postPosition(p);
}

static void mouse(int button, int state, int x, int y) {
	SGFPosition p(x / (float) ExampleUtil::screenWidth(), y / (float) ExampleUtil::screenHeight());

	if(state == GLUT_DOWN)
		gui->postButtonDown(button, p);
	else if(state == GLUT_UP)
		gui->postButtonUp(button, p);
}

int main(int argc, char argv[]) {
	glutInit(&argc, &argv);
	glutInitWindowSize(640, 480);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE);
	glutCreateWindow("SGF Example");
	ExampleUtil::initialize(640, 480);
	initialize();
	glutReshapeFunc(ExampleUtil::resize);
	glutDisplayFunc(render);
	glutIdleFunc(render);
	glutMouseFunc(mouse);
	glutPassiveMotionFunc(motion);
	glutMotionFunc(motion);
	glutMainLoop();
	finalize();
}