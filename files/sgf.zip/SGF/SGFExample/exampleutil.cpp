#include "exampleutil.h"
#include "GL/freeglut.h"

using namespace ExampleUtil;

/* FILE-SCOPE VARIABLES */
static int fScreenWidth = 0;
static int fScreenHeight = 0;

/* PUBLIC FUNCTIONS */
void ExampleUtil::setupFor3D() {
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, fScreenWidth / (float) fScreenHeight, 1.0f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
}

void ExampleUtil::draw3DBackground() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	static int time = glutGet(GLUT_ELAPSED_TIME);
	float timeStep = (glutGet(GLUT_ELAPSED_TIME) - time) / 1000.0f;
	time = glutGet(GLUT_ELAPSED_TIME);

	static float angle = 0.0f;
	angle += 30.0f * timeStep;
	if(angle > 360.0f)
		angle -= 360.0f;

	glPushMatrix();
		/* Big sphere */
		glTranslatef(3.0f, 1.0f, -15.0f);
		glRotatef(angle, 0.0f, 1.0f, 0.0f);
		glRotatef(angle, 0.3f, 0.0f, 0.0f);
		glRotatef(angle, 0.0f, 0.0f, 0.1f);
		glutWireSphere(3.0f, 32, 32);
		glPushMatrix();
		
		/* Small spheres */
		const int NUMBER_OF_SPHERES = 4;
		for(unsigned int i = 0; i < NUMBER_OF_SPHERES; i++) {
			glRotatef(360.0f / (float) NUMBER_OF_SPHERES, 1.0f, 0.0f, 0.0f);
			glPushMatrix();
				glTranslatef(0.0f, 5.0f, 0.0f);
				glutSolidSphere(1.0f, 32, 32);			
			glPopMatrix();
		}
		glPopMatrix();
	glPopMatrix();
}


void ExampleUtil::setupFor2D() {
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0f, 1.0f, 1.0f, 0.0f);
	glMatrixMode(GL_MODELVIEW);
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
}

void ExampleUtil::drawExampleRectangle(float x, float y, float width, float height, float alpha) {
	glPushMatrix();
		glTranslatef(x, y, 0.0f);
		glBegin(GL_QUADS);
			glColor4f(1.0f, 1.0f, 1.0f, alpha);
			glVertex2f(0.0f, 0.0f);
			glColor4f(0.0f, 1.0f, 1.0f, alpha);
			glVertex2f(0.0f, height);
			glColor4f(1.0f, 0.0f, 1.0f, alpha);
			glVertex2f(width, height);
			glColor4f(0.0f, 0.0f, 1.0f, alpha);
			glVertex2f(width, 0.0f);				  
		glEnd();
	glPopMatrix();
}

void ExampleUtil::drawCenteredText(float x, float y, const std::string& text) {
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glRasterPos2f(x - 0.5f * textWidth(text),
				  y + 0.25f * textHeight(text));
	glutBitmapString(GLUT_BITMAP_8_BY_13, (unsigned char *) text.c_str());
}

void ExampleUtil::initialize(int x, int y) {
	glLoadIdentity();
	resize(640, 480);
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glShadeModel(GL_SMOOTH);
	GLfloat pos[] = { 3.0f, 1.0f, 5.0f, 0.0f };
	glLightfv(GL_LIGHT0, GL_POSITION, pos);
	
	GLfloat col[] = {0.7f, 1.0f, 0.3f, 1.0f};
	GLfloat spec[] = {1.0f, 1.0f, 1.0f, 0.3f };
	glMaterialfv(GL_FRONT, GL_SPECULAR, spec);
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, col);
	glMaterialf(GL_FRONT, GL_SHININESS, 70.0f);
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void ExampleUtil::resize(int x, int y) {
	fScreenWidth = x;
	fScreenHeight = y;
	glViewport(0, 0, x, y);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, x / (float) y, 1.0f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
}

int ExampleUtil::screenWidth() {
	return fScreenWidth;
}

int ExampleUtil::screenHeight() {
	return fScreenHeight;
}

float ExampleUtil::textWidth(const std::string& text) {
	return glutBitmapLength(GLUT_BITMAP_8_BY_13, (unsigned char *) text.c_str()) / (float) fScreenWidth;
}

float ExampleUtil::textHeight(const std::string& text) {
	return glutBitmapHeight(GLUT_BITMAP_8_BY_13) / (float) fScreenHeight;
}