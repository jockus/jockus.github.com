// ***************************************************************
//  SGFComponent   version:  1.0   �  date: 01/14/2007
//  -------------------------------------------------------------
//  The SGFComponent class is the base for all functional components
//	within SGF. A component is something have a boundary and 
//	reacts to user input within that boundary in some way.
//	It provides empty implementations for its 
//	manipulators, specialized components are free to implement
//	those that are needed.
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGFCOMPONENT
#define INCLUDED_SGFCOMPONENT

#include "SGFRectangle.h"

class SGFUserEvent;

class SGFComponent {
	SGFRectangle mBounds;
public:
	/* CREATORS */
	SGFComponent(const SGFRectangle& bounds);
	virtual ~SGFComponent();

	/* MANIPULATORS */
	virtual void onButtonDown(int button, const SGFPosition& position);
	virtual void onButtonUp(int button, const SGFPosition& position);
	virtual void onChar(char c);
	virtual void onDraw(const SGFPosition& position);
	virtual void onFocus();
	virtual void onPosition(const SGFPosition& position);
	virtual void onUnFocus();
	virtual void onUserEvent(SGFUserEvent* event);

	/* ACCESSORS */
	bool isInside(const SGFPosition& position) const;
	const SGFRectangle& getBounds() const;
};

#endif