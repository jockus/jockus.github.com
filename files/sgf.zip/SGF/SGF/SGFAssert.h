// ***************************************************************
//  assert   version:  1.0   �  date: 11/23/2006
//  -------------------------------------------------------------
//  The assert component defines a macro for assertions, which works
//	both in realase and debug versions aswell as printing out the
//	assertion in a messagebox on windows-compiles.
//  -------------------------------------------------------------
//  Copyright (C) 2006 - All Rights Reserved
// ***************************************************************
//	Joakim Hentula
// ***************************************************************
#include <string>

namespace SGFAssertUtil {
	bool displayAssertion(const std::string& assertion, const std::string& description, const std::string& filename, int lineNumber, bool ignore);
}

#define SGFAssert(exp, description) { static bool ignore = false; if(!(exp)) { if(!ignore ) { if( SGFAssertUtil::displayAssertion(#exp, description, __FILE__, __LINE__, ignore) ) __asm { int 3  }; } } } ((void)0)
