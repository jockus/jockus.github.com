#include "SGUIAdjustment.h"

using namespace SGUI;

const Adjustment Adjustment::CENTER_CENTER(0.5f, 0.5f);
const Adjustment Adjustment::LEFT_CENTER(0.0f, 0.5f);
const Adjustment Adjustment::RIGHT_CENTER(1.0f, 0.5f);
const Adjustment Adjustment::LEFT_TOP(0.0f, 0.0f);
const Adjustment Adjustment::RIGHT_TOP(1.0f, 0.0f);
const Adjustment Adjustment::CENTER_TOP(0.5f, 0.0f);
const Adjustment Adjustment::LEFT_BOTTOM(0.0f, 1.0f);
const Adjustment Adjustment::RIGHT_BOTTOM(1.0f, 1.0f);
const Adjustment Adjustment::CENTER_BOTTOM(0.5f, 1.0f);

Adjustment::Adjustment(const Fraction& horizontal, const Fraction& vertical) :
	mHorizontal(horizontal),
	mVertical(vertical) {
}

void Adjustment::setHorizontalAdjustment(const Fraction& horizontal) {
	mHorizontal = horizontal;
}

void Adjustment::setVerticalAdjustment(const Fraction& vertical) {
	mVertical = vertical;
}

const Fraction& Adjustment::getHorizontalAdjustment() const {
	return mHorizontal;
}

const Fraction& Adjustment::getVerticalAdjustment() const {
	return mVertical;
}