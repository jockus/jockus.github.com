// ***************************************************************
//  SGUIBound   version:  1.0   �  date: 01/10/2007
//  -------------------------------------------------------------
//  The Bound class is an interface for the bounds a component in
//  SGUI can have.
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGUIBOUNDS
#define INCLUDED_SGUIBOUNDS

namespace SGUI {
	class Position;

	class Bounds {
	public:
		~Bounds();
		virtual bool isInside(const Position& position) = 0;
	};
}

#endif