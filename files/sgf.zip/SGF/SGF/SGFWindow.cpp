#include "SGFWindow.h"
#include "SGFAssert.h"
#include <algorithm>

/* PUBLIC MEMBER-FUNCTIONS */

SGFWindow::SGFWindow(const SGFRectangle& bounds) :
	SGFComponent(bounds),
	mFocused(0) {
}

SGFWindow::~SGFWindow() {
}

void SGFWindow::addComponent(SGFComponent* component) {
	SGFAssert(component != 0, "Invalid child component.");
	mComponents.push_back(component);
	SGFAssert(mComponents.back() == component, "Failed to add component.");
}

void SGFWindow::onButtonDown(int button, const SGFPosition& position) {
	if(mFocused)
		mFocused->onButtonDown(button, position - getBounds().getPosition());

}

void SGFWindow::onButtonUp(int button, const SGFPosition& position) {
	if(mFocused)
		mFocused->onButtonUp(button, position - getBounds().getPosition());
}

void SGFWindow::onChar(char c) {
	if(mFocused)
		mFocused->onChar(c);
}

void SGFWindow::onDraw(const SGFPosition& position) {
	for(Components::iterator i = mComponents.begin(); i != mComponents.end(); i++) {
		(*i)->onDraw(getBounds().getPosition() + position);
	}
}

void SGFWindow::onPosition(const SGFPosition& position) {
	if(isInside(position)) {
		if(mFocused) {
			if(mFocused->isInside(position - getBounds().getPosition())) {
				mFocused->onPosition(position - getBounds().getPosition());
				return;
			}
			else {
				mFocused->onUnFocus();
				mFocused = 0;
			}
		}
		for(Components::iterator i = mComponents.begin(); i != mComponents.end(); i++) {
			if((*i)->isInside(position - getBounds().getPosition())) {
				mFocused = *i;
				(*i)->onFocus();
			}
		}
	}
}

void SGFWindow::onUnFocus() {
	if(mFocused) {
		mFocused->onUnFocus();
		mFocused = 0;
	}
}

void SGFWindow::onUserEvent(SGFUserEvent* event) {
	if(mFocused)
		mFocused->onUserEvent(event);
}

void SGFWindow::removeComponent(SGFComponent* component) {
	SGFAssert(component != 0, "Invalid child component.");
	mComponents.erase(remove(mComponents.begin(), mComponents.end(), component), mComponents.end());
	//mComponents.remove(decorator);
}

SGFComponent* SGFWindow::getComponent(int index) const {
	SGFAssert(index < (int) mComponents.size(), "Invalid child index.");
	return mComponents[index];
}

int SGFWindow::getComponentCount() const {
	return (int) mComponents.size();
}