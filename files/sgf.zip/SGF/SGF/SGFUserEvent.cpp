#include "SGFUserEvent.h"

SGFUserEvent::SGFUserEvent(int id) :
	mID(id) {
}

SGFUserEvent::~SGFUserEvent() {
}

int SGFUserEvent::getID() const {
	return mID;
}