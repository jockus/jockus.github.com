// ***************************************************************
//  SGFWindow   version:  1.0   �  date: 01/11/2007
//  -------------------------------------------------------------
//  The SGFWindow class is a component within SGF.
//	It's purpose is to define a relative space which within a number
//	of child components can be added. All events posted in this space
//	will passed along to it's child components.
//	To achieve this it filters out all events that aren't inside its 
//	boundary, as well as expressing position-sensitive events such as
//	onPosition, onButtonDown and onButtonUp in it's own relative space,
//	with one exception;
//	onDraw - the position a child recieves is the Windows global position.
//	The childcomponent must then subsequentially use this position as a
//  reference point to determine it's own global position. The reason for
//	this is that you will most likely be interested in the components
//	physical global position instead of it's logical relative position when
//	you draw a it.
//	If any of the eventmessages are overloaded the base SGFWindow-class functions
//	must be called prior to any action taken, e.g.:
//
//		void GLWindow::onPosition(const SGFPosition& position) {
//			SGF::SGFWindow::onPosition(position);		//calling base member
//			*** proceed with GLWindow-specific code ***
//		}
//
//	with, as above, onDraw the exception, since you would normally want to draw
//	the window bottom-up. To achieve this, the base function should be called 
//	AFTER the specific drawing code, e.g.:
//
//		void GLWindow::onDraw(const SGFPosition& position) {
//			*** draw your GLWindow ***
//			SGF::SGFWindow::onDraw(position);	//then pass the draw message to the base class
//											//which will pass it along to the child components.
//		}
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGFWINDOW
#define INCLUDED_SGFWINDOW

#include <vector>
#include "SGFComponent.h"

class SGFRectangle;
class SGFPosition;
class SGFUserEvent;
class SGFWindow;

class SGFWindow : public SGFComponent {
	typedef std::vector<SGFComponent*> Components;
	Components mComponents;
	SGFComponent* mFocused;

	SGFWindow(const SGFWindow&);				//Not implemented
	SGFWindow& operator=(const SGFWindow&);	//Not implemented
	bool invariant() const;
public:
	/* CREATORS */
	SGFWindow(const SGFRectangle& bounds);
	virtual ~SGFWindow();

	/* MANIPULATORS */
	void addComponent(SGFComponent* component);
	void onButtonDown(int button, const SGFPosition& position);
	void onButtonUp(int button, const SGFPosition& position);
	void onDraw(const SGFPosition& position);
	void onChar(char c);
	void onPosition(const SGFPosition& position); 
	void onUnFocus();
	void onUserEvent(SGFUserEvent* event);
	void removeComponent(SGFComponent* component);

	/* ACCESSORS */
	SGFComponent* getComponent(int index) const;
	int getComponentCount() const;
};

#endif