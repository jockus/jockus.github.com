#include "SGFAssert.h"
#include <strstream>
#include <iostream>
#ifdef WIN32
	#define WIN32_LEAN_AND_MEAN
	#include <windows.h>
#endif

bool SGFAssertUtil::displayAssertion(const std::string& assertion, const std::string& description, const std::string& filename, int lineNumber, bool ignore) {
#ifdef WIN32
	std::strstream s;
	s << "Error, Assertion failed:" << std::endl << std::endl
		<< assertion << " -- \"" << description << "\"" << std::endl
		<< "In file: " << filename << ", At line: " << lineNumber << '\0';
	switch (MessageBox(NULL, s.str(), "Assertion failed", MB_ABORTRETRYIGNORE))
	{
	case IDIGNORE:
		ignore = true;
		break;
	case IDABORT:
		return true;
	}
	return false;
#else
	std::cerr << "Error, Assertion failed:" << std::endl << std::endl
		<< assertion << " -- \"" << description << "\"" << std::endl
		<< "In file: " << filename << ", At line: " << lineNumber << std::endl;
	return true;
#endif
}
