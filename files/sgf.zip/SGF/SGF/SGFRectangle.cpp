#include "SGFRectangle.h"
#include "SGFAlignment.h"
#include "SGFAssert.h"

/* FILE-SCOPE FUNCTIONS */
SGFPosition fToAligned(const SGFPosition& position, const SGFAlignment& alignment, float width, float height) {
	return position - SGFPosition(width * alignment.getHorizontal(), height * alignment.getVertical());
}

/* PUBLIC MEMBER FUNCTIONS */
SGFRectangle::SGFRectangle(const SGFPosition& position, float width, float height) :
	mPosition(position),
	mWidth(width),
	mHeight(height),
	mAlignment(0.0f, 0.0f) {
	SGFAssert(invariant(), "Invariant failed.");
}
SGFRectangle::SGFRectangle(const SGFPosition& position, const SGFAlignment& alignment, float width, float height) :
	mPosition(position),
	mWidth(width),
	mHeight(height),
	mAlignment(alignment) {
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFRectangle::setAlignment(const SGFAlignment& alignment) {
	SGFAssert(invariant(), "Invariant failed.");
	mAlignment = alignment;
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFRectangle::setPosition(const SGFPosition& position) {
	SGFAssert(invariant(), "Invariant failed.");
	mPosition = position;
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFRectangle::setHeight(float height) {
	SGFAssert(invariant(), "Invariant failed.");
	mHeight = height;
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFRectangle::setWidth(float width) {
	SGFAssert(invariant(), "Invariant failed.");
	mWidth = width;
	SGFAssert(invariant(), "Invariant failed.");
}

const SGFAlignment& SGFRectangle::getAlignment() const {
	SGFAssert(invariant(), "Invariant failed.");
	return mAlignment;
}

SGFPosition SGFRectangle::getPosition() const {
	SGFAssert(invariant(), "Invariant failed.");
	return fToAligned(mPosition, mAlignment, mWidth, mHeight);;
}

float SGFRectangle::getHeight() const {
	SGFAssert(invariant(), "Invariant failed.");
	return mHeight;
}

float SGFRectangle::getWidth() const {
	SGFAssert(invariant(), "Invariant failed.");
	return mWidth;
}

bool SGFRectangle::isInside(const SGFPosition& position) const {
	SGFAssert(invariant(), "Invariant failed.");
	SGFPosition p = fToAligned(mPosition, mAlignment, mWidth, mHeight);
	return (position.getX() >= p.getX() && position.getX() < p.getX() + mWidth &&
			position.getY() >= p.getY() && position.getY() < p.getY() + mHeight);
}


/* PRIVATE MEMBER FUNCTIONS */
bool SGFRectangle::invariant() const {
	return mWidth >= 0.0f && mHeight >= 0.0f;
}