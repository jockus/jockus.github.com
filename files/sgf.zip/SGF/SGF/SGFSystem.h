// ***************************************************************
//  SGFSystem   version:  1.0   �  date: 01/14/2007
//  -------------------------------------------------------------
//  The SGFSystem class is a means to group together a tree of SGF
//	components and have a unified means of delegating events to it.
//	In most cases the root component will be a SGFWindow covering
//	the entire interactable user interface area, to provide a
//	root which delegates only relevant events.
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGFSYSTEM
#define INCLUDED_SGFSYSTEM

#include <list>

class SGFWindow;
class SGFPosition;
class SGFUserEvent;

class SGFSystem {
	SGFWindow* mRootWindow;

	bool invariant() const;
public:
	/* CREATORS */
	SGFSystem(SGFWindow* rootWindow);
	~SGFSystem();

	/* MANIPULATORS */
	void postButtonDown(int button, const SGFPosition& position);
	void postButtonUp(int button, const SGFPosition& position);
	void postChar(char c);
	void postDraw();
	void postPosition(const SGFPosition& position);
	void postUserEvent(SGFUserEvent* e);
	void setRootWindow(SGFWindow* root);

	/* ACCESSORS */
	SGFWindow* getRootWindow() const;
};

#endif