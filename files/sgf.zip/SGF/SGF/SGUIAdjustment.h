// ***************************************************************
//  SGUIAdjustment   version:  1.0   �  date: 01/09/2007
//  -------------------------------------------------------------
//  The Adjustment class represents the adjustment of a position.
//	The adjustment consists of a horizontal and a vertical adjustment,
//  which are fractions.
//	The adjustment class also defines a couple of useful constants.
//		LEFT_TOP = 0.0, 0.0
//		RIGHT_BOTTON = 1.0, 1.0
//		CENTER_CENTER = 0.5, 0.5
//	etc.
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGUIADJUSTMENT
#define INCLUDED_SGUIADJUSTMENT

#include "SGUIFraction.h"

namespace SGUI {
class Adjustment {
	Fraction mHorizontal, mVertical;
public:
	/* CREATORS */
	Adjustment(const Fraction& horizontal, const Fraction& vertical);
	
	/* MANIPULATORS */
	void setHorizontalAdjustment(const Fraction& horizontal);
	void setVerticalAdjustment(const Fraction& vertical);
	
	/* ACCESSORS */
	const Fraction& getHorizontalAdjustment() const;
	const Fraction& getVerticalAdjustment() const;

	static const Adjustment CENTER_CENTER;
	static const Adjustment LEFT_CENTER;
	static const Adjustment RIGHT_CENTER;
	static const Adjustment LEFT_TOP;
	static const Adjustment RIGHT_TOP;
	static const Adjustment CENTER_TOP;
	static const Adjustment LEFT_BOTTOM;
	static const Adjustment RIGHT_BOTTOM;
	static const Adjustment CENTER_BOTTOM;
};
}

#endif