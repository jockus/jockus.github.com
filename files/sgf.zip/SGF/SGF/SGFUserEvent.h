// ***************************************************************
//  SGFUserEvent   version:  1.0   �  date: 01/11/2007
//  -------------------------------------------------------------
//  The SGFUserEvent class gives users of the SGF library a way of
//  implementing new operations on SGF components. By giving each
//	new user defined event a unique ID run time type checking is 
//	possible without the use of RTTI.
//	If RTTI is favored, the id can simply be ignored.
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGFUSEREVENT
#define INCLUDED_SGFUSEREVENT

class SGFUserEvent {
	int mID;
	
public:
	/* CREATORS */
	SGFUserEvent(int id);
	virtual ~SGFUserEvent();

	/* ACCESSORS */
	int getID() const;
};

#endif