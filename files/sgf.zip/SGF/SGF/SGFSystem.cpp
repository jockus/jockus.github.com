#include "SGFSystem.h"
#include "SGFWindow.h"
#include "SGFAssert.h"

SGFSystem::SGFSystem(SGFWindow* rootWindow) :
	mRootWindow(rootWindow) {
	SGFAssert(invariant(), "Invariant failed.");
}

SGFSystem::~SGFSystem() {
	SGFAssert(invariant(), "Invariant failed.");
	mRootWindow = 0;
	SGFAssert(!invariant(), "Inverse invariant failed.");
}

void SGFSystem::postButtonDown(int button, const SGFPosition& position) {
	SGFAssert(invariant(), "Invariant failed.");
	mRootWindow->onButtonDown(button, position);
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFSystem::postButtonUp(int button, const SGFPosition& position) {
	SGFAssert(invariant(), "Invariant failed.");
	mRootWindow->onButtonUp(button, position);
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFSystem::postDraw() {
	SGFAssert(invariant(), "Invariant failed.");
	mRootWindow->onDraw(SGFPosition(0.0f, 0.0f));
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFSystem::postChar(char c) {
	SGFAssert(invariant(), "Invariant failed.");
	mRootWindow->onChar(c);
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFSystem::postPosition(const SGFPosition& position) {
	SGFAssert(invariant(), "Invariant failed.");
	mRootWindow->onPosition(position);
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFSystem::postUserEvent(SGFUserEvent* event) {
	SGFAssert(invariant(), "Invariant failed.");
	SGFAssert(event != 0, "Invalid user event.");
	mRootWindow->onUserEvent(event);
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFSystem::setRootWindow(SGFWindow* root) {
	SGFAssert(invariant(), "Invariant failed.");
	SGFAssert(root != 0, "Invalid root SGFWindow-pointer.");
	mRootWindow = root;
	SGFAssert(invariant(), "Invariant failed.");
}

SGFWindow* SGFSystem::getRootWindow() const {
	SGFAssert(invariant(), "Invariant failed.");
	return mRootWindow;
}

/* PRIVATE MEMBER FUNCTIONS */
bool SGFSystem::invariant() const {
	return mRootWindow != 0;
}