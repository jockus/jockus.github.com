// ***************************************************************
//  SGFPosition   version:  1.0   �  date: 01/09/2007
//  -------------------------------------------------------------
//  The SGFPosition class represents a 2D position within SGF
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGFPOSITION
#define INCLUDED_SGFPOSITION

class SGFPosition {
	float mX, mY;
public:
	/* CREATORS */
	SGFPosition(float x, float y) :
		mX(x),
		mY(y) {
	}

	/* MANIPULATORS */
	void setX(float x) {
		mX = x;
	}
	void setY(float y) {
		mY = y;
	}
	
	/* ACCESSORS */
	float getX() const {
		return mX;
	}
	float getY() const {
		return mY;
	}
	SGFPosition operator+(const SGFPosition& position) const {
		return SGFPosition(getX() + position.getX(), getY() + position.getY());
	}
	SGFPosition operator-(const SGFPosition& position) const {
		return SGFPosition(getX() - position.getX(), getY() - position.getY());
	}
};

#endif