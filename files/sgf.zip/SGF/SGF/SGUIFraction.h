// ***************************************************************
//  SGUIFraction   version:  1.0   �  date: 01/09/2007
//  -------------------------------------------------------------
//  The Fraction class represents a fraction - a decimal number
//  between 0 and 1. It will cap any values larger or smaller than
//	to it's closest valid value.
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGUIFRACTION
#define INCLUDED_SGUIFRACTION

namespace SGUI {

	class Fraction {
		float mFraction;
		bool invariant() const;
	public:
		/* CREATORS */
		Fraction(float fraction);
		~Fraction();

		/* MANIPULATORS */
		void setFraction(float fraction);

		/* ACCESSORS */
		float getFraction() const;
/* 		Fraction operator+(const SGUI::Fraction& fraction) const {
			return Fraction(getFraction() + fraction.getFraction());
		}
		Fraction operator-(const SGUI::Fraction& fraction) const {
			return Fraction(getFraction() - fraction.getFraction());
		}
		Fraction operator*(const SGUI::Fraction& fraction) const {
			return Fraction(getFraction() * fraction.getFraction());
		}
		bool operator>(const SGUI::Fraction& fraction) const {
			return getFraction() > fraction.getFraction();
		}
		bool operator<(const SGUI::Fraction& fraction) const {
			return getFraction() < fraction.getFraction();
		}*/
	};
}

#endif