#include "SGFComponent.h"

/* PUBLIC MEMBER FUNCTIONS */
SGFComponent::SGFComponent(const SGFRectangle& bounds) :
	mBounds(bounds) {
}

SGFComponent::~SGFComponent() {
}

void SGFComponent::onButtonDown(int button, const SGFPosition& position) {
}

void SGFComponent::onButtonUp(int button, const SGFPosition& position) {
}

void SGFComponent::onChar(char c) {
}

void SGFComponent::onDraw(const SGFPosition& position) {
}

void SGFComponent::onFocus() {
}

void SGFComponent::onPosition(const SGFPosition& position) {
}

void SGFComponent::onUnFocus() {
}

void SGFComponent::onUserEvent(SGFUserEvent* event) {
}

bool SGFComponent::isInside(const SGFPosition& position) const {
	return mBounds.isInside(position);
}

const SGFRectangle& SGFComponent::getBounds() const {
	return mBounds;
}