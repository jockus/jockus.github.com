#include "SGFAlignment.h"
#include "SGFAssert.h"

/* CONSTANT DEFINES */
const SGFAlignment SGFAlignment::UPPER_LEFT(0.0f, 0.0f);
const SGFAlignment SGFAlignment::UPPER_RIGHT(1.0f, 0.0f);
const SGFAlignment SGFAlignment::CENTER(0.5f, 0.5f);
const SGFAlignment SGFAlignment::LOWER_LEFT(0.0f, 1.0f);
const SGFAlignment SGFAlignment::LOWER_RIGHT(1.0f, 1.0f);

/* PUBLIC MEMBER-FUNCTIONS */
SGFAlignment::SGFAlignment(float horizontalFraction, float verticalFraction) :
	mHorizontal(horizontalFraction),
	mVertical(verticalFraction) {
	SGFAssert(invariant(), "Invariant failed.");
}

SGFAlignment::~SGFAlignment() {
	SGFAssert(invariant(), "Invariant failed.");
	mHorizontal = -1.0f;
	SGFAssert(!invariant(), "Inverse invariant failed.");
}

void SGFAlignment::setHorizontal(float fraction) {
	SGFAssert(invariant(), "Invariant failed.");
	mHorizontal = fraction;
	SGFAssert(invariant(), "Invariant failed.");
}

void SGFAlignment::setVertical(float fraction) {
	SGFAssert(invariant(), "Invariant failed.");
	mVertical = fraction;
	SGFAssert(invariant(), "Invariant failed.");
}

float SGFAlignment::getHorizontal() const {
	return mHorizontal;
}

float SGFAlignment::getVertical() const {
	return mVertical;
}

/* PRIVATE MEMBER-FUNCTIONS */
bool SGFAlignment::invariant() const {
	return (mHorizontal >= 0.0f && mHorizontal <= 1.0f) &&
			(mVertical >= 0.0f && mVertical <= 1.0f);
}