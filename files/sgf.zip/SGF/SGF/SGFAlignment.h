// ***************************************************************
//  SGFAlignment   version:  1.0   �  date: 01/13/2007
//  -------------------------------------------------------------
//  The SGFAlignment class represents an aligment of a components
//	position in SGF. The alignments are represented by fractions
//	-- i.e. a number between 0 and 1.
//  The alignment is determined as:
//	(0.0f, 0.0f) -- upper left corner
//		to
//	(1.0f, 1.0f) -- lower right corner
//	A couple of useful constant alignments are also defined:
//	UPPER_LEFT		(0.0f, 0.0f)
//	UPPER_RIGHT		(1.0f, 0.0f)
//	CENTER			(0.5f, 0.5f)
//	LOWER_LEFT		(0.0f, 1.0f)
//	LOWER_RIGHT		(1.0f, 1.0f)
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGFALIGNMENT
#define INCLUDED_SGFALIGNMENT

class SGFAlignment {
	float mHorizontal, mVertical;

	bool invariant() const;
public:
	/* CREATORS */
	SGFAlignment(float horizontalFraction, float verticalFraction);
	~SGFAlignment();

	/* MANIPULATORS */
	void setHorizontal(float fraction);
	void setVertical(float fraction);

	/* ACCESSORS */
	float getHorizontal() const;
	float getVertical() const;

	static const SGFAlignment UPPER_LEFT;
	static const SGFAlignment UPPER_RIGHT;
	static const SGFAlignment CENTER;
	static const SGFAlignment LOWER_LEFT;
	static const SGFAlignment LOWER_RIGHT;
};

#endif