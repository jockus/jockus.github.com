// ***************************************************************
//  SGF   version:  1.0   �  date: 01/14/2007
//  -------------------------------------------------------------
//  This file is purely for the comfort of the client, if he wishes
//	to include all SGF files at once.
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGF
#define INCLUDED_SGF

#include "SGFAlignment.h"
#include "SGFAssert.h"
#include "SGFComponent.h"
#include "SGFPosition.h"
#include "SGFRectangle.h"
#include "SGFSystem.h"
#include "SGFUserEvent.h"
#include "SGFWindow.h"

#endif