#include "SGUIFraction.h"
#include "SGUIAssert.h"

using namespace SGUI;

/* PUBLIC MEMBER FUNCTIONS */
Fraction::Fraction(float fraction) :
	mFraction(0.0f) {
	Assert(invariant(), "Invariant failed.");
	setFraction(fraction);
	Assert(invariant(), "Invariant failed.");
}

Fraction::~Fraction() {
	Assert(invariant(), "Invariant failed.");
	mFraction = -1.0f;
	Assert(!invariant(), "Inverse invariant failed.");
}

void Fraction::setFraction(float fraction) {
	Assert(invariant(), "Invariant failed.");
	mFraction = fraction;
	if(mFraction > 1.0f)
		mFraction = 1.0f;
	else if(mFraction < 0.0f)
		mFraction = 0.0f;
	Assert(invariant(), "Invariant failed.");
}

float Fraction::getFraction() const {
	Assert(invariant(), "Invariant failed.");
	return mFraction;
}

/* PRIVATE MEMBER FUNCTIONS */
bool Fraction::invariant() const {
	return mFraction >= 0.0f && mFraction <= 1.0f;
}