#include "SGUIBounds.h"

SGUI::Bounds::~Bounds() {
}