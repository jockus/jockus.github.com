// ***************************************************************
//  SGFRectangle   version:  1.0   �  date: 01/09/2007
//  -------------------------------------------------------------
//  The SGFRectangle class represents a 2D-rectangle within SGF.
//  A rectangle is defined by a position and a width and height.
//  The alignment of the rectangle determines where the position is
//  located within a rectangle.
//	Width and height must be positive non-zero values.
//  Default alignment is left upper corner.
//  It defines a functions for checking if a point is inside the
//	rectangle or not.
//  -------------------------------------------------------------
//  Copyright (C) 2007 - All Rights Reserved
// ***************************************************************
//  Joakim Hentula
// ***************************************************************
#ifndef INCLUDED_SGFRECTANGLE
#define INCLUDED_SGFRECTANGLE

#include "SGFPosition.h"
#include "SGFAlignment.h"

class SGFRectangle
{
	SGFPosition mPosition;
	float mWidth;
	float mHeight;
	SGFAlignment mAlignment;

	bool invariant() const;
public:
	/* CREATORS */
	SGFRectangle(const SGFPosition& position, float width, float height);
	SGFRectangle(const SGFPosition& position, const SGFAlignment& alignment, float width, float height);
	
	/* MAINPULATORS */
	void setAlignment(const SGFAlignment& alignment);
	void setHeight(float height);
	void setPosition(const SGFPosition& position);
	void setWidth(float width);		
	
	/* ACCESSORS */
	const SGFAlignment& getAlignment() const;
	SGFPosition getPosition() const;
	float getHeight() const;
	float getWidth() const;
	bool isInside(const SGFPosition& position) const;
};

#endif