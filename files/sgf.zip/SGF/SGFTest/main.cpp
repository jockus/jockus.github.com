#include <iostream>
#include "SGF.h"

void testSGFAssert() {
	//SGFAssert(false, "SGFAssert test: This should show. Press retry.");
	SGFAssert(true, "SGFAssert error");
}

void testSGFPosition() {
	SGFPosition p1(0.0f, 0.0f);
	SGFAssert(p1.getX() == 0.0f, "SGFPosition error.");
	SGFAssert(p1.getY() == 0.0f, "SGFPosition error.");
	SGFPosition p2(20.0f, 20.0f);
	SGFAssert(p2.getX() == 20.0f, "SGFPosition error.");
	SGFAssert(p2.getY() == 20.0f, "SGFPosition error.");
	p1 = p2;
	SGFAssert(p1.getX() == 20.0f, "SGFPosition error.");
	SGFAssert(p1.getY() == 20.0f, "SGFPosition error.");
	p1 = SGFPosition(0.1f, 0.2f);
	p2 = SGFPosition(0.4f, 0.3f);
	SGFPosition p3 = p1 + p2;
	SGFAssert(p3.getX() == 0.5f, "SGFPosition error.");
	SGFAssert(p3.getY() == 0.5f, "SGFPosition error.");
	p3 = p3 - SGFPosition(5.0f, 10.0f);
	SGFAssert(p3.getX() == -4.5f, "SGFPosition error.");
	SGFAssert(p3.getY() == -9.5f, "SGFPosition error.");
	p3.setX(0.0f);
	p3.setY(0.0f);
	SGFAssert(p3.getX() == 0.0f, "SGFPosition error.");
	SGFAssert(p3.getY() == 0.0f, "SGFPosition error.");
}

void testSGFAlignment() {
	SGFAlignment a(0.0f, 0.0f);
	SGFAssert(a.getHorizontal() == 0.0f, "SGFAlignment error.");
	SGFAssert(a.getVertical() == 0.0f, "SGFAlignment error.");
	a.setHorizontal(1.0f);
	SGFAssert(a.getHorizontal() == 1.0f, "SGFAlignment error.");
	SGFAssert(a.getVertical() == 0.0f, "SGFAlignment error.");
	a.setVertical(1.0f);
	SGFAssert(a.getHorizontal() == 1.0f, "SGFAlignment error.");
	SGFAssert(a.getVertical() == 1.0f, "SGFAlignment error.");
	SGFAlignment b(a);
	SGFAssert(b.getHorizontal() == 1.0f, "SGFAlignment error.");
	SGFAssert(b.getVertical() == 1.0f, "SGFAlignment error.");
	SGFAssert(SGFAlignment::UPPER_LEFT.getHorizontal() == 0.0f, "SGFAlignment error.");
	SGFAssert(SGFAlignment::UPPER_LEFT.getVertical() == 0.0f, "SGFAlignment error.");
	SGFAssert(SGFAlignment::UPPER_RIGHT.getHorizontal() == 1.0f, "SGFAlignment error.");
	SGFAssert(SGFAlignment::UPPER_RIGHT.getVertical() == 0.0f, "SGFAlignment error.");
	SGFAssert(SGFAlignment::CENTER.getHorizontal() == 0.5f, "SGFAlignment error.");
	SGFAssert(SGFAlignment::CENTER.getVertical() == 0.5f, "SGFAlignment error.");
	SGFAssert(SGFAlignment::LOWER_LEFT.getHorizontal() == 0.0f, "SGFAlignment error.");
	SGFAssert(SGFAlignment::LOWER_LEFT.getVertical() == 1.0f, "SGFAlignment error.");
	SGFAssert(SGFAlignment::LOWER_RIGHT.getHorizontal() == 1.0f, "SGFAlignment error.");
	SGFAssert(SGFAlignment::LOWER_RIGHT.getVertical() == 1.0f, "SGFAlignment error.");
}

void testSGFRectangle() {
	SGFRectangle r(SGFPosition(0.0f, 0.0f), 1.0f, 1.0f);
	SGFAssert(r.isInside(SGFPosition(0.5f, 0.5f)), "SGFRectangle error.");
	r.setAlignment(SGFAlignment(1.0f, 1.0f));	//Align to lower right corner - now spanning from -1.0f, -1.0f to 0.0f, 0.0f
	SGFAssert(!r.isInside(SGFPosition(0.5f, 0.5f)), "SGFRectangle error.");
	r.setAlignment(SGFAlignment(0.5f, 0.0f));
	SGFAssert(r.getAlignment().getHorizontal() == 0.5f, "SGFRectangle error.");
	SGFAssert(r.getAlignment().getVertical() == 0.0f, "SGFRectangle error.");
	r.setAlignment(SGFAlignment(0.0f, 0.0f));
	r.setWidth(5.0f);
	r.setHeight(10.0f);
	SGFAssert(r.getWidth() == 5.0f, "SGFRectangle error.");
	SGFAssert(r.getHeight() == 10.0f, "SGFRectangle error.");
	r.setPosition(SGFPosition(4.0f, 3.0f));
	SGFAssert(r.getPosition().getX() == 4.0f, "SGFRectangle error.");
	SGFAssert(r.getPosition().getY() == 3.0f, "SGFRectangle error.");
}

void testSGFUserEvent() {
	SGFUserEvent u(0);
	SGFAssert(u.getID() == 0, "Invariant failed");
}

void testSGFComponent() {
	SGFRectangle b(SGFPosition(0.0f, 0.0f), 1.0f, 1.0f);
	SGFComponent c(b);
	SGFAssert(c.isInside(SGFPosition(0.5f, 0.5f)), "SGFComponent error.");
	SGFAssert(c.getBounds().getPosition().getX() == b.getPosition().getX(), "SGFComponent error.");
	SGFAssert(c.getBounds().getPosition().getY() == b.getPosition().getY(), "SGFComponent error.");
	SGFAssert(c.getBounds().getWidth() == b.getWidth(), "SGFComponent error.");
	SGFAssert(c.getBounds().getHeight() == b.getHeight(), "SGFComponent error.");
	c.onButtonDown(0, SGFPosition(0.0f, 0.0f));
	c.onButtonUp(0, SGFPosition(0.0f, 0.0f));
	c.onChar('a');
	c.onDraw(SGFPosition(0.0f, 0.0f));
	c.onFocus();
	c.onPosition(SGFPosition(0.0f, 0.0f));
	c.onUnFocus();
	SGFUserEvent* u = (SGFUserEvent*) 0;
	c.onUserEvent(u);
}

class TestComponent : public SGFComponent {
public:
	bool onButtonDownWasCalled;
	bool onButtonUpWasCalled;
	bool onCharWasCalled;
	bool onDrawWasCalled;
	bool onFocusWasCalled;
	bool onPositionWasCalled;
	bool onUnFocusWasCalled;
	bool onUserEventWasCalled;

	TestComponent() :
		SGFComponent(SGFRectangle(SGFPosition(0.1f, 0.1f), 0.8f, 0.8f)),
		onButtonDownWasCalled(false),
		onButtonUpWasCalled(false), 
		onCharWasCalled(false),
		onDrawWasCalled(false),
		onFocusWasCalled(false),
		onPositionWasCalled(false),
		onUnFocusWasCalled(false),
		onUserEventWasCalled(false) {
	}
	virtual void onButtonDown(int button, const SGFPosition& position) {
		onButtonDownWasCalled = true;
	}
	virtual void onButtonUp(int button, const SGFPosition& position) {
		onButtonUpWasCalled = true;
	}
	virtual void onChar(char c) {
		onCharWasCalled = true;
	}
	virtual void onDraw(const SGFPosition& position) {
		onDrawWasCalled = true;
	}
	virtual void onFocus() {
		onFocusWasCalled = true;
	}
	virtual void onPosition(const SGFPosition& position) {
		onPositionWasCalled = true;
	}
	virtual void onUnFocus() {
		onUnFocusWasCalled = true;
	}
	virtual void onUserEvent(SGFUserEvent* event) {
		onUserEventWasCalled = true;
	}
};

void testSGFWindow() {
	SGFRectangle b(SGFPosition(0.0f, 0.0f), 1.0f, 1.0f);
	SGFWindow w(b);
	TestComponent c;

	w.addComponent(&c);
	SGFAssert(w.getComponent(0) == &c, "SGFWindow error.");
	SGFAssert(w.getComponentCount() == 1, "SGFWindow error.");

	//the component isn't focused yet
	SGFAssert(!c.onFocusWasCalled, "SGFWindow error.");
	//We must move the cursor on top of the testcomponent for it to be focused
	w.onPosition(SGFPosition(0.5f, 0.5f));
	//test if it was focused
	SGFAssert(c.onFocusWasCalled, "SGFWindow error.");

	SGFAssert(!c.onButtonDownWasCalled, "SGFWindow error.");
	w.onButtonDown(0, SGFPosition(0.5f, 0.5f));
	SGFAssert(c.onButtonDownWasCalled, "SGFWindow error.");
	
	SGFAssert(!c.onButtonUpWasCalled, "SGFWindow error.");
	w.onButtonUp(0, SGFPosition(0.5f, 0.5f));
	SGFAssert(c.onButtonUpWasCalled, "SGFWindow error.");
	
	SGFAssert(!c.onCharWasCalled, "SGFWindow error.");
	w.onChar('a');
	SGFAssert(c.onCharWasCalled, "SGFWindow error.");
	
	SGFAssert(!c.onDrawWasCalled, "SGFWindow error.");
	w.onDraw(SGFPosition(0.0f, 0.0f));
	SGFAssert(c.onDrawWasCalled, "SGFWindow error.");
	
	SGFAssert(!c.onPositionWasCalled, "SGFWindow error.");
	w.onPosition(SGFPosition(0.6f, 0.6f));
	SGFAssert(c.onPositionWasCalled, "SGFWindow error.");
	
	SGFAssert(!c.onUserEventWasCalled, "SGFWindow error.");
	w.onUserEvent((SGFUserEvent*) 0);
	SGFAssert(c.onUserEventWasCalled, "SGFWindow error.");

	SGFAssert(!c.onUnFocusWasCalled, "SGFWindow error.");
	//move the cursor outside of window
	w.onPosition(SGFPosition(0.0f, 0.0f));
	//now it should've been unfocused.
	SGFAssert(c.onUnFocusWasCalled, "SGFWindow error.");

}


class TestWindow : public SGFWindow {
public:
	bool onButtonDownWasCalled;
	bool onButtonUpWasCalled;
	bool onCharWasCalled;
	bool onDrawWasCalled;
	bool onFocusWasCalled;
	bool onPositionWasCalled;
	bool onUnFocusWasCalled;
	bool onUserEventWasCalled;

	TestWindow() :
	SGFWindow(SGFRectangle(SGFPosition(0.0f, 0.0f), 1.0f, 1.0f)),
		onButtonDownWasCalled(false),
		onButtonUpWasCalled(false), 
		onCharWasCalled(false),
		onDrawWasCalled(false),
		onFocusWasCalled(false),
		onPositionWasCalled(false),
		onUnFocusWasCalled(false),
		onUserEventWasCalled(false) {
	}
	virtual void onButtonDown(int button, const SGFPosition& position) {
		SGFWindow::onButtonDown(button, position);
		onButtonDownWasCalled = true;
	}
	virtual void onButtonUp(int button, const SGFPosition& position) {
		SGFWindow::onButtonUp(button, position);
		onButtonUpWasCalled = true;
	}
	virtual void onChar(char c) {
		SGFWindow::onChar(c);
		onCharWasCalled = true;
	}
	virtual void onDraw(const SGFPosition& position) {
		SGFWindow::onDraw(position);
		onDrawWasCalled = true;
	}
	virtual void onFocus() {
		SGFWindow::onFocus();
		onFocusWasCalled = true;
	}
	virtual void onPosition(const SGFPosition& position) {
		SGFWindow::onPosition(position);
		onPositionWasCalled = true;
	}
	virtual void onUnFocus() {
		SGFWindow::onUnFocus();
		onUnFocusWasCalled = true;
	}
	virtual void onUserEvent(SGFUserEvent* event) {
		SGFWindow::onUserEvent(event);
		onUserEventWasCalled = true;
	}
};

void testSGFSystem() {
	SGFRectangle b(SGFPosition(0.0f, 0.0f), 1.0f, 1.0f);
	TestWindow r;
	SGFRectangle b2(SGFPosition(0.1f, 0.1f), 0.8f, 0.8f);
	SGFComponent c(b2);
	r.addComponent(&c);
	SGFSystem s(&r);
	SGFAssert(s.getRootWindow() == &r, "SGFSystem error.");
	
	SGFAssert(!r.onButtonDownWasCalled, "SGFSystem error.");
	s.postButtonDown(0, SGFPosition(0.0f, 0.0f));
	SGFAssert(r.onButtonDownWasCalled, "SGFSystem error.");
	
	SGFAssert(!r.onButtonUpWasCalled, "SGFSystem error.");
	s.postButtonUp(0, SGFPosition(0.0f, 0.0f));
	SGFAssert(r.onButtonUpWasCalled, "SGFSystem error.");
	
	SGFAssert(!r.onCharWasCalled, "SGFSystem error.");
	s.postChar('a');
	SGFAssert(r.onCharWasCalled, "SGFSystem error.");

	
	SGFAssert(!r.onDrawWasCalled, "SGFSystem error.");
	s.postDraw();
	SGFAssert(r.onDrawWasCalled, "SGFSystem error.");
	
	SGFAssert(!r.onPositionWasCalled, "SGFSystem error.");
	s.postPosition(SGFPosition(0.0f, 0.0f));
	SGFAssert(r.onPositionWasCalled, "SGFSystem error.");
	
	SGFUserEvent u(0);
	SGFAssert(!r.onUserEventWasCalled, "SGFSystem error.");
	s.postUserEvent(&u);
	SGFAssert(r.onUserEventWasCalled, "SGFSystem error.");

}

int main() {
	testSGFAssert();
	testSGFPosition();
	testSGFAlignment();
	testSGFRectangle();
	testSGFUserEvent();
	testSGFComponent();
	testSGFWindow();
	testSGFSystem();

	return 0;
}